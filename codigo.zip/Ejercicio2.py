import tkinter as tk
from tkinter import ttk, messagebox

# ===============================
# Función para preparar expresiones
# ===============================
def preparar_expresion(expr: str) -> str:
    expr = expr.replace(" ", "")          # quitar espacios
    expr = expr.replace("^", "**")        # potencia
    expr = expr.replace("-x", "-1*x")     # caso -x
    expr = expr.replace("+x", "+1*x")     # caso +x
    if expr.startswith("x"):              # si empieza con x
        expr = "1*" + expr
    expr = expr.replace("x", "*x")        # poner multiplicación
    expr = expr.replace("**x", "*x")      # corregir si se duplicó
    return expr

# ===============================
# Función para graficar la región factible
# ===============================
def graficar():
    func_input = entrada.get()
    if not func_input.strip():
        messagebox.showwarning("Error", "Ingresa la función de la recta (ej: (20-3*x)/5).")
        return

    func = preparar_expresion(func_input)
    xmin, xmax = -1, 10
    ymin, ymax = -1, 6

    resultado_texto = ""

    for y in range(ymax, ymin - 1, -1):
        linea = ""
        for x in range(xmin, xmax + 1):
            try:
                y_line = eval(func)
            except:
                y_line = None

            # Condición para la recta
            cond_line = (y_line is not None and abs(y - y_line) < 0.5)

            # Condición para la región factible: debajo de la recta y primer cuadrante
            cond_region = (y_line is not None and y <= y_line and x >= 0 and y >= 0)

            # Dibujar símbolos
            if cond_line:
                linea += "*"
            elif cond_region:
                linea += "o"
            elif x == 0 and y == 0:
                linea += "+"
            elif x == 0:
                linea += "|"
            elif y == 0:
                linea += "-"
            else:
                linea += " "
        resultado_texto += linea + "\n"

    # Leyenda
    resultado_texto += "\nLeyenda del gráfico:\n"
    resultado_texto += "  * = Recta 3x + 5y = 20 (frontera)\n"
    resultado_texto += "  o = Región factible (3x + 5y <= 20, x>=0, y>=0)\n"
    resultado_texto += "  | = Eje Y\n"
    resultado_texto += "  - = Eje X\n"
    resultado_texto += "  + = Origen (0,0)\n"

    resultado.configure(state="normal")
    resultado.delete("1.0", "end")
    resultado.insert("1.0", resultado_texto)
    resultado.configure(state="disabled")

# ===============================
# Función limpiar
# ===============================
def limpiar():
    entrada.delete(0, "end")
    resultado.configure(state="normal")
    resultado.delete("1.0", "end")
    resultado.configure(state="disabled")

# ===============================
# GUI Futurista
# ===============================
ventana = tk.Tk()
ventana.title("🚀 Región Factible Futurista")
ventana.geometry("700x500")
ventana.resizable(False, False)
ventana.configure(bg="#0B0C10")

# Estilos
estilo = ttk.Style()
estilo.theme_use("clam")

estilo.configure(
    "BotonFuturista.TButton",
    font=("Segoe UI Semibold", 11),
    padding=8,
    background="#1F2833",
    foreground="#66FCF1",
    borderwidth=0,
)
estilo.map(
    "BotonFuturista.TButton",
    background=[("active", "#45A29E"), ("disabled", "#1F2833")],
    foreground=[("active", "white")]
)

estilo.configure(
    "EntradaFuturista.TEntry",
    fieldbackground="#1F2833",
    foreground="#C5C6C7",
    insertcolor="#66FCF1",
    padding=6,
    relief="flat",
)

# Título
titulo = tk.Label(
    ventana,
    text="🌌 Graficador Región Factible",
    font=("Orbitron", 16, "bold"),
    fg="#66FCF1",
    bg="#0B0C10",
)
titulo.pack(pady=(20,10))

# Marco de entrada
marco_entrada = tk.Frame(ventana, bg="#0B0C10")
marco_entrada.pack(pady=5)

entrada = ttk.Entry(
    marco_entrada,
    font=("Consolas", 14),
    width=30,
    style="EntradaFuturista.TEntry",
)
entrada.pack(side="left", padx=10)
entrada.insert(0, "(20-3*x)/5")

btn_graficar = ttk.Button(
    marco_entrada,
    text="Graficar",
    style="BotonFuturista.TButton",
    command=graficar
)
btn_graficar.pack(side="left", padx=5)

btn_limpiar = ttk.Button(
    marco_entrada,
    text="Limpiar",
    style="BotonFuturista.TButton",
    command=limpiar
)
btn_limpiar.pack(side="left", padx=5)

ventana.bind("<Return>", lambda e: graficar())

# Marco de resultados
marco_resultado = tk.LabelFrame(
    ventana,
    text="📊 RESULTADOS",
    font=("Segoe UI", 11, "bold"),
    fg="#66FCF1",
    bg="#0B0C10",
    labelanchor="n",
    bd=2,
    relief="groove"
)
marco_resultado.pack(fill="both", expand=True, padx=20, pady=15)

scrollbar = tk.Scrollbar(marco_resultado)
scrollbar.pack(side="right", fill="y")

resultado = tk.Text(
    marco_resultado,
    font=("Consolas", 12),
    bg="#1F2833",
    fg="#C5C6C7",
    relief="flat",
    wrap="word",
    yscrollcommand=scrollbar.set,
    state="disabled"
)
resultado.pack(fill="both", expand=True, padx=10, pady=10)
scrollbar.config(command=resultado.yview)

ventana.mainloop()
