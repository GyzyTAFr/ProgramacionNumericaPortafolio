import tkinter as tk
from tkinter import ttk, messagebox

# ===============================
# Función para preparar expresiones lineales
# ===============================
def preparar_expresion(expr: str) -> str:
    expr = expr.replace(" ", "")          # quitar espacios
    expr = expr.replace("^", "**")        # potencia
    expr = expr.replace("-x", "-1*x")     # caso -x
    expr = expr.replace("+x", "+1*x")     # caso +x
    if expr.startswith("x"):              # si empieza con x
        expr = "1*" + expr
    expr = expr.replace("x", "*x")        # poner multiplicación
    expr = expr.replace("**x", "*x")      # corregir si se duplicó
    return expr

# ===============================
# Función para graficar región factible
# ===============================
def graficar():
    restric2 = entrada2.get()
    if not restric2.strip():
        messagebox.showwarning("Error", "Ingresa la restricción de la segunda recta (ej: -x+15).")
        return

    func2 = preparar_expresion(restric2)
    xmin, xmax = -5, 20
    ymin, ymax = -5, 20

    resultado_texto = ""

    for y in range(ymax, ymin - 1, -1):
        linea = ""
        for x in range(xmin, xmax + 1):
            # Recta 1: x = 5
            cond1 = (x == 5)

            # Recta 2: y = -x + 15
            try:
                y2 = eval(func2)
            except:
                y2 = None
            cond2 = (y2 is not None and abs(y - y2) < 0.5)

            # Región factible: x>=5, y>=0, x+y<=15
            region = (x >= 5 and y >= 0 and x + y <= 15)

            # Qué dibujar
            if cond1 and cond2:
                linea += "#"
            elif cond1:
                linea += "*"
            elif cond2:
                linea += "o"
            elif x == 0 and y == 0:
                linea += "+"
            elif x == 0:
                linea += "|"
            elif y == 0:
                linea += "-"
            elif region:
                linea += "."
            else:
                linea += " "
        resultado_texto += linea + "\n"

    # Leyenda
    resultado_texto += "\nLeyenda del gráfico:\n"
    resultado_texto += "  * = x = 5\n"
    resultado_texto += "  o = x + y = 15\n"
    resultado_texto += "  # = Intersección\n"
    resultado_texto += "  . = Región factible\n"
    resultado_texto += "  | = Eje Y\n"
    resultado_texto += "  - = Eje X\n"
    resultado_texto += "  + = Origen (0,0)\n"

    resultado.configure(state="normal")
    resultado.delete("1.0", "end")
    resultado.insert("1.0", resultado_texto)
    resultado.configure(state="disabled")

# ===============================
# Función limpiar
# ===============================
def limpiar():
    entrada2.delete(0, "end")
    resultado.configure(state="normal")
    resultado.delete("1.0", "end")
    resultado.configure(state="disabled")

# ===============================
# GUI Futurista
# ===============================
ventana = tk.Tk()
ventana.title("🚀 Región Factible Futurista")
ventana.geometry("700x500")
ventana.resizable(False, False)
ventana.configure(bg="#0B0C10")

# Estilos
estilo = ttk.Style()
estilo.theme_use("clam")

estilo.configure(
    "BotonFuturista.TButton",
    font=("Segoe UI Semibold", 11),
    padding=8,
    background="#1F2833",
    foreground="#66FCF1",
    borderwidth=0,
)
estilo.map(
    "BotonFuturista.TButton",
    background=[("active", "#45A29E"), ("disabled", "#1F2833")],
    foreground=[("active", "white")]
)

estilo.configure(
    "EntradaFuturista.TEntry",
    fieldbackground="#1F2833",
    foreground="#C5C6C7",
    insertcolor="#66FCF1",
    padding=6,
    relief="flat",
)

# Título
titulo = tk.Label(
    ventana,
    text="🌌 Graficador de Región Factible",
    font=("Orbitron", 16, "bold"),
    fg="#66FCF1",
    bg="#0B0C10",
)
titulo.pack(pady=(20,10))

# Marco de entrada
marco_entrada = tk.Frame(ventana, bg="#0B0C10")
marco_entrada.pack(pady=5)

entrada2 = ttk.Entry(
    marco_entrada,
    font=("Consolas", 14),
    width=25,
    style="EntradaFuturista.TEntry",
)
entrada2.pack(side="left", padx=10)
entrada2.insert(0, "-x+15")

btn_graficar = ttk.Button(
    marco_entrada,
    text="Graficar",
    style="BotonFuturista.TButton",
    command=graficar
)
btn_graficar.pack(side="left", padx=5)

btn_limpiar = ttk.Button(
    marco_entrada,
    text="Limpiar",
    style="BotonFuturista.TButton",
    command=limpiar
)
btn_limpiar.pack(side="left", padx=5)

ventana.bind("<Return>", lambda e: graficar())

# Marco de resultados
marco_resultado = tk.LabelFrame(
    ventana,
    text="📊 RESULTADOS",
    font=("Segoe UI", 11, "bold"),
    fg="#66FCF1",
    bg="#0B0C10",
    labelanchor="n",
    bd=2,
    relief="groove"
)
marco_resultado.pack(fill="both", expand=True, padx=20, pady=15)

scrollbar = tk.Scrollbar(marco_resultado)
scrollbar.pack(side="right", fill="y")

resultado = tk.Text(
    marco_resultado,
    font=("Consolas", 12),
    bg="#1F2833",
    fg="#C5C6C7",
    relief="flat",
    wrap="word",
    yscrollcommand=scrollbar.set,
    state="disabled"
)
resultado.pack(fill="both", expand=True, padx=10, pady=10)
scrollbar.config(command=resultado.yview)

ventana.mainloop()
