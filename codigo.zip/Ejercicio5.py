import tkinter as tk
from tkinter import ttk

def graficar():
    resultado_texto = ""
    xmin, xmax = -1, 12
    ymin, ymax = -1, 7

    for y in range(ymax, ymin - 1, -1):
        linea = ""
        for x in range(xmin, xmax + 1):

            # Recta de frontera: x + 2y = 10
            y_line = (10 - x) / 2 if (10 - x) >= 0 else None

            # Condición recta
            cond_line = (y_line is not None and abs(y - y_line) < 0.5)

            # Condición región factible
            cond_region = (x >= 0 and y >= 0 and (x + 2*y <= 10))

            # Dibujar con prioridad
            if cond_line:
                linea += "*"
            elif cond_region:
                linea += "o"
            elif x == 0 and y == 0:
                linea += "+"
            elif x == 0:
                linea += "|"
            elif y == 0:
                linea += "-"
            else:
                linea += " "
        resultado_texto += linea + "\n"

    # Leyenda
    resultado_texto += "\nLeyenda del gráfico:\n"
    resultado_texto += "  * = Frontera (x + 2y = 10)\n"
    resultado_texto += "  o = Región factible (x + 2y <= 10, x>=0, y>=0)\n"
    resultado_texto += "  | = Eje Y\n"
    resultado_texto += "  - = Eje X\n"
    resultado_texto += "  + = Origen (0,0)\n"

    resultado.configure(state="normal")
    resultado.delete("1.0", "end")
    resultado.insert("1.0", resultado_texto)
    resultado.configure(state="disabled")

def limpiar():
    resultado.configure(state="normal")
    resultado.delete("1.0", "end")
    resultado.configure(state="disabled")

# ------------------- GUI -------------------
ventana = tk.Tk()
ventana.title("🚀 Problema 5 - Dispositivos A y B")
ventana.geometry("800x500")
ventana.configure(bg="#0B0C10")

# Estilos
estilo = ttk.Style()
estilo.theme_use("clam")
estilo.configure(
    "BotonFuturista.TButton",
    font=("Segoe UI Semibold", 11),
    padding=8,
    background="#1F2833",
    foreground="#66FCF1",
    borderwidth=0
)
estilo.map(
    "BotonFuturista.TButton",
    background=[("active", "#45A29E")],
    foreground=[("active", "white")]
)

# Título
titulo = tk.Label(
    ventana,
    text="🌌 Problema 5 - Región Factible",
    font=("Arial", 16, "bold"),
    fg="#66FCF1",
    bg="#0B0C10"
)
titulo.pack(pady=(20,10))

# Botones
marco_botones = tk.Frame(ventana, bg="#0B0C10")
marco_botones.pack(pady=5)

btn_graficar = ttk.Button(marco_botones, text="Graficar", style="BotonFuturista.TButton", command=graficar)
btn_graficar.pack(side="left", padx=5)

btn_limpiar = ttk.Button(marco_botones, text="Limpiar", style="BotonFuturista.TButton", command=limpiar)
btn_limpiar.pack(side="left", padx=5)

ventana.bind("<Return>", lambda e: graficar())

# Caja de resultados
marco_resultado = tk.LabelFrame(
    ventana,
    text="📊 RESULTADOS",
    font=("Segoe UI", 11, "bold"),
    fg="#66FCF1",
    bg="#0B0C10",
    labelanchor="n",
    bd=2,
    relief="groove"
)
marco_resultado.pack(fill="both", expand=True, padx=20, pady=15)

scrollbar = tk.Scrollbar(marco_resultado)
scrollbar.pack(side="right", fill="y")

resultado = tk.Text(
    marco_resultado,
    font=("Consolas", 12),
    bg="#1F2833",
    fg="#C5C6C7",
    relief="flat",
    wrap="none",
    yscrollcommand=scrollbar.set
)
resultado.pack(fill="both", expand=True, padx=10, pady=10)
scrollbar.config(command=resultado.yview)

ventana.mainloop()
