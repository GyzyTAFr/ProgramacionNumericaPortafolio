import tkinter as tk
from tkinter import ttk, messagebox

# ===============================
# Función para preparar expresiones
# ===============================
def preparar_expresion(expr: str) -> str:
    expr = expr.replace(" ", "")
    expr = expr.replace("^", "**")
    expr = expr.replace("-x", "-1*x")
    expr = expr.replace("+x", "+1*x")
    if expr.startswith("x"):
        expr = "1*" + expr
    expr = expr.replace("x", "*x")
    expr = expr.replace("**x", "*x")
    return expr

# ===============================
# Función para graficar la región factible
# ===============================
def graficar():
    resultado_texto = ""
    xmin, xmax = 0, 14
    ymin, ymax = 0, 14

    for y in range(ymax, ymin - 1, -1):
        linea = ""
        for x in range(xmin, xmax + 1):

            # Restricciones
            cond_recta = (abs(x + y - 12) < 0.5)   # frontera x+y=12
            cond_x = (x == 4)                      # frontera x=4
            cond_y = (y == 6)                      # frontera y=6

            # Región factible
            cond_region = (x >= 4 and y >= 6 and (x + y <= 12))

            # Vértices
            vertices = [(4,6), (4,8), (6,6)]
            cond_vertice = (x,y) in vertices

            # Dibujar con prioridad
            if cond_vertice:
                linea += "#"
            elif cond_region:
                linea += "o"
            elif cond_recta:
                linea += "*"
            elif cond_x:
                linea += "|"
            elif cond_y:
                linea += "="
            elif x == 0 and y == 0:
                linea += "+"
            elif x == 0:
                linea += "|"
            elif y == 0:
                linea += "-"
            else:
                linea += " "
        resultado_texto += linea + "\n"

    # Leyenda
    resultado_texto += "\nLeyenda:\n"
    resultado_texto += "  * = Frontera x+y=12\n"
    resultado_texto += "  | = Frontera x=4\n"
    resultado_texto += "  = = Frontera y=6\n"
    resultado_texto += "  # = Vértices de la región factible\n"
    resultado_texto += "  o = Región factible (sombreada)\n"
    resultado_texto += "  + = Origen\n"
    resultado_texto += "  - , | = Ejes coordenados\n"

    resultado.configure(state="normal")
    resultado.delete("1.0", "end")
    resultado.insert("1.0", resultado_texto)
    resultado.configure(state="disabled")

# ===============================
# Función limpiar
# ===============================
def limpiar():
    resultado.configure(state="normal")
    resultado.delete("1.0", "end")
    resultado.configure(state="disabled")

# ===============================
# GUI Futurista
# ===============================
ventana = tk.Tk()
ventana.title("🚀 Región Factible Avanzada")
ventana.geometry("700x500")
ventana.resizable(False, False)
ventana.configure(bg="#0B0C10")

# Estilos
estilo = ttk.Style()
estilo.theme_use("clam")

estilo.configure(
    "BotonFuturista.TButton",
    font=("Segoe UI Semibold", 11),
    padding=8,
    background="#1F2833",
    foreground="#66FCF1",
    borderwidth=0,
)
estilo.map(
    "BotonFuturista.TButton",
    background=[("active", "#45A29E"), ("disabled", "#1F2833")],
    foreground=[("active", "white")]
)

# Título
titulo = tk.Label(
    ventana,
    text="🌌 Graficador Región Factible Avanzada",
    font=("Orbitron", 16, "bold"),
    fg="#66FCF1",
    bg="#0B0C10",
)
titulo.pack(pady=(20,10))

# Marco de botones
marco_botones = tk.Frame(ventana, bg="#0B0C10")
marco_botones.pack(pady=5)

btn_graficar = ttk.Button(
    marco_botones,
    text="Graficar",
    style="BotonFuturista.TButton",
    command=graficar
)
btn_graficar.pack(side="left", padx=5)

btn_limpiar = ttk.Button(
    marco_botones,
    text="Limpiar",
    style="BotonFuturista.TButton",
    command=limpiar
)
btn_limpiar.pack(side="left", padx=5)

ventana.bind("<Return>", lambda e: graficar())

# Marco de resultados
marco_resultado = tk.LabelFrame(
    ventana,
    text="📊 RESULTADOS",
    font=("Segoe UI", 11, "bold"),
    fg="#66FCF1",
    bg="#0B0C10",
    labelanchor="n",
    bd=2,
    relief="groove"
)
marco_resultado.pack(fill="both", expand=True, padx=20, pady=15)

scrollbar = tk.Scrollbar(marco_resultado)
scrollbar.pack(side="right", fill="y")

resultado = tk.Text(
    marco_resultado,
    font=("Consolas", 12),
    bg="#1F2833",
    fg="#C5C6C7",
    relief="flat",
    wrap="word",
    yscrollcommand=scrollbar.set,
    state="disabled"
)
resultado.pack(fill="both", expand=True, padx=10, pady=10)
scrollbar.config(command=resultado.yview)

ventana.mainloop()


